create table municipios(
codigo integer not null primary key,
nome varchar(100) not null,
uf char(2) not null,
latitude double precision,
longitude double precision);

select * from municipios;

insert into municipios values (1,'Alegrete','RS',-29.7116,-55.5261),
(2,'Passo Fundo','RS',-28.2294,-52.4039),(3,'Marau','RS',-28.433883,-52.210215);

select * from municipios;

create extension postgis;

SELECT AddGeometryColumn( 'municipios', 'geom', 4326, 'POINT', 2); 

update municipios set 
geom = ST_SetSRID(ST_MakePoint(longitude,latitude), 4326);

select (st_distance ((select geom::geography from municipios where codigo=2), 
                     (select geom::geography from municipios where codigo=3)))/1000;

