create table cidades(
codigo integer not null primary key,
nome varchar(100) not null,
uf char(2) not null);

create table filmes(
codigo integer not null primary key,
descricao varchar(100) not null);

create type tendereco as(
rua varchar(50) ,
numero integer,
cep char(8));

create table pessoas(
codigo integer not null primary key,
nome varchar(100) not null,
endereco tendereco,
cidade integer references cidades,
telefones varchar(10) []);

create table pessoas_filmes(
codigo integer not null primary key,
pessoa integer not null references pessoas,
filme integer not null references filmes);

create table fisicas(
cpf char(11) not null,
rg char(10) not null,
primary key(codigo))
inherits (pessoas);

create table juridicas(
cnpj char(14) not null,
ie char(15) not null,
primary key(codigo))
inherits (pessoas);

select * from pessoas;
select * from fisicas;
select * from juridicas;

insert into cidades values (1,'Marau','RS');

insert into pessoas values (1,'Maria',row('Morom',100,'99999999'),1,
                                           array['999999','88888']);
                                           
insert into fisicas values (1,'Paulo',row('Morom',100,'99999999'),1,
                                           array['999999','88888'],'787979','90990');

select nome, telefones[1],telefones[2]
from fisicas

 