library(shiny)
setwd("/Users/alexandretagliarilazzaretti/Library/Mobile Documents/com~apple~CloudDocs/Lazzaretti/aulas/IFSUL/aulas/2023/2o Semestre/03-TBD/Linguagem R/Exemplos")
#inicializando os valores
estacao <- 49
variavel<-"tmin"
shinyUI(fluidPage(
  titlePanel("Hello Shiny ex03!"),
  sidebarLayout(
    sidebarPanel(    
      uiOutput('selectLocais'),
      uiOutput('selectVariavel'),
      width = 3
    ),     
    mainPanel(      
      tabsetPanel(type = "tabs", 
                  tabPanel("Plot", plotOutput("saidaPlot"))
      )            
    )
  )   
))