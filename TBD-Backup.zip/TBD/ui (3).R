library(shiny)
library(leaflet)

shinyUI(fluidPage(
  titlePanel("Dados do raster/shapefile"),
  
  
  mainPanel(
    leafletOutput("scatter", height=750, width = 750)
  )
))