library(DBI)
library(RPostgres)
library(dygraphs)
library(xts)
library(ggplot2)
library(plotly)
library(leaflet)

pdbbanco <- "DB_TBD2"
pdbuser <- "postgres"
pdbpassword <- "postgres"
pdbhost <- "localhost"
pdbport <- "5432"


executaConsulta <- function(sql){
  con <- dbConnect(RPostgres::Postgres(), user=pdbuser,
                   dbname=pdbbanco,
                   password=pdbpassword,
                   host=pdbhost,port=pdbport)
  rs = dbSendQuery(con, sql)
  df <- dbFetch(rs)
  dbClearResult(rs)
  dbDisconnect(con)
  return (df)
}

lerDados <- function(limit = 50) {
  valorID <- 1
  print(paste("Recebe valor do ID:", valorID))
  
  # Usa cláusula LIMIT para limitar o número de linhas
  sql <- sprintf("SELECT * FROM (
                    SELECT *, ST_X(geom) AS longitude, ST_Y(geom) AS latitude
                    FROM (
                      SELECT (ST_PixelAsPoints(rast, 1)).* FROM state_raster WHERE id = %s
                    ) foo
                  ) AS data
                  LIMIT %d;", valorID, limit)
  
  # Certifique-se de ter a função executaConsulta definida em seu código
  dados_carbono <- executaConsulta(sql)
  return(dados_carbono)
}

resultados_lerDados <- lerDados()
print(resultados_lerDados)

lerDados_shape <- function(valorID) {
  print(paste("Recebe valor do ID:", valorID))
  
  sql2 <- sprintf("SELECT x, y, val, st_X(geom) as latitude, st_Y(geom) as longitude
FROM (
    SELECT (st_pixelaspoints((
        SELECT(ST_Union(ST_Clip(rast,
        ST_Transform((SELECT geom FROM municipios_ibge WHERE gid=%s),
        ST_SRID(rast) ) ) ) ) AS rast 
        FROM state_raster 		   
        WHERE ST_Intersects(rast, (SELECT geom FROM municipios_ibge WHERE gid=%s))), 1)
    ).*) r1
LIMIT 50;", valorID, valorID)
  dados_carbono2 <- executaConsulta(sql2)
  return(dados_carbono2)
}

resultados_lerDados_shape <- lerDados_shape(1)
print(resultados_lerDados_shape)




