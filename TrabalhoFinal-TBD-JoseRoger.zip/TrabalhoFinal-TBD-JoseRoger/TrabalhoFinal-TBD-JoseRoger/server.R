library(shiny)
library(leaflet)
library(sf)
setwd("C:/Users/José/Documents/TrabalhoFinal-TBD-JoseRoger/R")
source("functions.R")
valorID = "1"
shinyServer(function(input, output) {  
  dados <- reactive({
    valorID = input$valorID
    lerDados(valorID)
  })   
  dados_shape <- reactive({
    valorID = input$municipioID
    lerDados_shape(valorID)
  })   
  observeEvent(input$updateButton, {
    valorID <- input$valorID
    print(paste("Aualiza valor do ID para:", valorID))
    dados <- lerDados(valorID)
    
  })
  output$saidaPlot <- renderPlot({
    dados <- dados()
    plot(dados$val~dados$x, xlab = "X", ylab = "Altitude",
         main="Grafico de  Valores:")    
  })  
  output$saidaTabela <- renderDataTable({
    dados <- dados() 
    dados
  })
  output$saidaTabelaShape <- renderDataTable({
    dados <- dados_shape() 
    dados
  })
  output$map <- renderLeaflet({
    dados_mapa <- dados()
    leaflet() %>%
      addTiles() %>%
      addMarkers(data = dados_mapa, lng = ~longitude, lat = ~latitude, popup = ~paste("Altura: ", val, "m", sep = "")) 
  })
  output$map_shape <- renderLeaflet({
    dados_mapa_shape <- dados_shape()
    leaflet() %>%
      addTiles() %>%
      addMarkers(data = dados_mapa_shape, lng = ~latitude, lat = ~longitude, popup = ~paste("Altura: ", val, "m", sep = "")) 
  })
})
