library(shiny)
library(leaflet)
setwd("C:/Users/José/Documents/TrabalhoFinal-TBD-JoseRoger/R")
source("server.R")
#inicializando os valores
municipioID <- "1"
rotulos <- c("Opção 9", "Opção 33", "Opção 34", "Opção 50", "Opção 65", "Opção 74", "Opção 88")
shinyUI(fluidPage(
  titlePanel("Trabalho TBD Carbono Jose-Roger"),
  sidebarLayout(
    sidebarPanel(    
      radioButtons("tipoPlot", "Tipo do Plotagem:",
                   c("Ponto" = "p", "Linha" = "l")
      ),       
      numericInput("valorID", "Valor em ID:", value = valorID),
      selectInput("municipioID", "Selecionar município por ID:",
                  choices = c(9, 33, 34, 50, 65, 74, 88),
                  selected = municipioID)
    ),     
    mainPanel(      
      tabsetPanel(type = "tabs", 
                  tabPanel("Plotagem", plotOutput("saidaPlot")),                   
                  tabPanel("Tabela de Dados", dataTableOutput("saidaTabela")),
                  tabPanel("Mapa", leafletOutput("map")),
                  tabPanel("Tabela Shapefile", dataTableOutput("saidaTabelaShape")),
                  tabPanel("Mapa Shapefile", leafletOutput("map_shape"))
      )            
    )
  )   
))