library(shiny)
setwd("/Users/alexandretagliarilazzaretti/Library/Mobile Documents/com~apple~CloudDocs/Lazzaretti/aulas/IFSUL/aulas/2023/2o Semestre/03-TBD/Linguagem R/Exemplos/exemplo1")
source("functions.R")

shinyServer(function(input, output) {
  
  output$saida <- renderPlot({
    
    elementos <- input$elementos
    valorInicial <- input$valorInicial
    valorFinal <- input$valorFinal
    tipoPlot <- input$tipoPlot
    
    dados <- gerarDados_1(elementos,valorInicial,valorFinal)
    
    plot(dados$x~dados$y, xlab = "Elementos", ylab = "Valores",
         main="Grafico com geracao de dados aleatorios",type=tipoPlot)    
  })
})