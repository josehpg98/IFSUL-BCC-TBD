select * from raster_data where id=1;
select * from shape_file;
select * from shape_file where id=6

-- CONSULTA QUE RETORNA OS DADOS DE UMA FORMA
SELECT x,y,val,st_X(geom) as latitude,st_Y(geom) as longitude
FROM
(select(st_pixelaspoints((    SELECT(ST_Union(ST_Clip(rast,
ST_Transform((select geom from shape_file where id=6),
ST_SRID(rast) ) ) ) ) AS rast from raster_data 		   
WHERE
ST_Intersects(rast, (select geom from shape_file where id=6))),1)).*) r1

-- CONSULTA QUE RETORNA OS DADOS DE UMA COORDENANA
SELECT st_value(rast,st_setsrid(st_makepoint(-63,-19),4326))
FROM raster_data
WHERE ST_Intersects(rast,
st_setsrid(st_makepoint(-63,-19),4326));

select *, st_X(geom) as longitude, st_Y(geom) as latitude
from (SELECT (ST_PixelAsPoints(rast, 1)).* 
FROM raster_data 
WHERE 
ST_Intersects(rast,
st_setsrid(st_makepoint(-63,-19),4326))) foo;
