select creditos.codigo as numero, pessoas.nome as pessoa, 
       creditos.valor, creditos.data_vencimento
from (creditos join vendas on vendas.codigo=creditos.venda) left join
	pessoas on pessoas.codigo=vendas.pessoa_cliente
order by creditos.codigo, creditos.venda, pessoas.nome;
      

select * from creditos
select * from vendas
select * from pessoas

copy (select creditos.codigo as numero, pessoas.nome as pessoa, 
       creditos.valor, creditos.data_vencimento
from (creditos join vendas on vendas.codigo=creditos.venda) left join
	pessoas on pessoas.codigo=vendas.pessoa_cliente
order by creditos.codigo, creditos.venda, pessoas.nome) to 
'/Users/alexandretagliarilazzaretti/Lazzaretti/lixo/creditos.txt' delimiter ';'

-- Crie uma tabela e facca a importacao do arquivo: 16.csv

drop table importa;

create table importa (
id serial primary key,
campo1 double precision,
campo2 double precision,
campo3 double precision,
campo4 double precision,
campo5 double precision);

copy importa (campo1,campo2,campo3,campo4,campo5) 
from '/Users/alexandretagliarilazzaretti/Lazzaretti/lixo/16.csv' delimiter ','

select * from importa;



