library(shiny)
library(leaflet)
library(sp)
library(dplyr)
library(ggplot2)

setwd("/Users/alexandretagliarilazzaretti/Library/Mobile Documents/com~apple~CloudDocs/Lazzaretti/aulas/IFSUL/aulas/2023/2o Semestre/03-TBD/Linguagem R/Exemplo LeafLet")
source("functions.R")

shinyServer(function(output, input) {
  
  ##graphData.SP <- SpatialPointsDataFrame(graphData[,c(2,3)],graphData[,-c(2,3)])
  
  output$scatter <- renderLeaflet({ 
    
    graphData = gerarDadosMapa()
    
    ##graphData$lat <- as.numeric(graphData$lat)
    ##graphData$long <- as.numeric(graphData$long)
    
    leaflet() %>%
      addTiles() %>%  # use the default base map which is OpenStreetMap tiles
      addMarkers(lng=174.768, lat=-36.852,
                 popup="The birthplace of R")
  
  })
})